from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

from app.routers import matches, custom

app = FastAPI(
    title="Football AI Intelligence Platform",
    description="แพลตฟอร์มวิเคราะห์และค้นหาความคุ้มค่าฟุตบอลด้วย AI — แยก Fact / Analysis / Uncertainty ชัดเจน",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS สำหรับ frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(matches.router)
app.include_router(custom.router)


@app.get("/api/health")
async def health():
    from app.services.data_service import provider_name
    from app import config
    return {
        "status": "ok",
        "service": config.APP_NAME,
        "version": config.APP_VERSION,
        "data_provider": provider_name(),
        "message": "ระบบพร้อมใช้งาน"
    }


# Serve frontend static files
frontend_path = os.path.join(os.path.dirname(__file__), "..", "..", "frontend")
if os.path.exists(frontend_path):
    app.mount("/static", StaticFiles(directory=os.path.join(frontend_path, "public")), name="static")

    @app.get("/")
    async def serve_frontend():
        index_path = os.path.join(frontend_path, "public", "index.html")
        if os.path.exists(index_path):
            return FileResponse(index_path)
        return {"message": "Frontend not found. API is running at /docs"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
