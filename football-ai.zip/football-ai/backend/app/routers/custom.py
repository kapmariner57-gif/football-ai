"""
Custom / Manual Analysis
ผู้ใช้กรอกทีม + ค่าน้ำเอง → ระบบวิเคราะห์ Value ให้
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from datetime import datetime

from app.models.schemas import MatchAnalysis
from app.services.analysis_engine import analyze_match
from app.data.sample_matches import SAMPLE_MATCHES

router = APIRouter(prefix="/api/custom", tags=["custom"])


class CustomOddsInput(BaseModel):
    home_team: str = Field(..., min_length=1, example="Arsenal")
    away_team: str = Field(..., min_length=1, example="Chelsea")
    competition: str = Field(default="Custom", example="Premier League")

    # 1X2
    home_odds: float = Field(..., gt=1.01, example=2.10)
    draw_odds: float = Field(..., gt=1.01, example=3.40)
    away_odds: float = Field(..., gt=1.01, example=3.50)

    # Optional markets
    over_25_odds: Optional[float] = Field(None, gt=1.01, example=1.85)
    under_25_odds: Optional[float] = Field(None, gt=1.01, example=2.00)
    btts_yes_odds: Optional[float] = Field(None, gt=1.01, example=1.75)
    btts_no_odds: Optional[float] = Field(None, gt=1.01, example=2.10)

    # Optional context
    home_xg: Optional[float] = Field(None, ge=0.3, le=4.0, example=1.8)
    away_xg: Optional[float] = Field(None, ge=0.3, le=4.0, example=1.3)
    note: Optional[str] = Field(None, max_length=500)


def _build_temp_match(data: CustomOddsInput) -> str:
    """สร้าง match ชั่วคราวใน SAMPLE_MATCHES แล้วคืน match_id"""
    match_id = f"custom_{int(datetime.utcnow().timestamp())}"

    home_xg = data.home_xg if data.home_xg else 1.5
    away_xg = data.away_xg if data.away_xg else 1.3

    # ปรับ xG หยาบ ๆ จากราคา 1X2 ถ้าผู้ใช้ไม่ได้ใส่
    if data.home_xg is None and data.away_xg is None:
        inv_h = 1.0 / data.home_odds
        inv_a = 1.0 / data.away_odds
        total_inv = inv_h + inv_a + (1.0 / data.draw_odds)
        # normalize rough strength
        home_xg = round(0.9 + 1.4 * (inv_h / total_inv), 2)
        away_xg = round(0.9 + 1.4 * (inv_a / total_inv), 2)

    ou_over = data.over_25_odds or 1.85
    ou_under = data.under_25_odds or 2.00
    btts_y = data.btts_yes_odds or 1.80
    btts_n = data.btts_no_odds or 2.05

    SAMPLE_MATCHES[match_id] = {
        "match_id": match_id,
        "home_team": data.home_team.strip(),
        "away_team": data.away_team.strip(),
        "competition": data.competition.strip() or "Custom",
        "kickoff": datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        "status": "scheduled",
        "venue": "Manual Input",
        "home_form": {
            "last_5": ["W", "D", "W", "L", "W"],
            "goals_scored": 8,
            "goals_conceded": 6,
            "xg_for": home_xg * 5,
            "xg_against": away_xg * 4.5,
            "points": 8,
        },
        "away_form": {
            "last_5": ["D", "W", "L", "W", "D"],
            "goals_scored": 7,
            "goals_conceded": 7,
            "xg_for": away_xg * 5,
            "xg_against": home_xg * 4.5,
            "points": 7,
        },
        "key_players": {"home": [], "away": []},
        "h2h": {"last_5": [], "home_wins": 0, "draws": 0, "away_wins": 0},
        "situational": [
            "วิเคราะห์จากค่าน้ำที่ผู้ใช้กรอกเอง",
            data.note or "ไม่มีหมายเหตุเพิ่มเติม",
        ],
        "raw_stats": {
            "home_avg_xg": home_xg,
            "away_avg_xg": away_xg,
            "home_avg_xga": round(1.1 + (2.0 - home_xg) * 0.3, 2),
            "away_avg_xga": round(1.1 + (2.0 - away_xg) * 0.3, 2),
            "home_possession": 52,
            "away_possession": 48,
            "home_ppda": 11.0,
            "away_ppda": 12.0,
        },
        "odds": {
            "1X2": {
                "home": {"opening": data.home_odds, "current": data.home_odds},
                "draw": {"opening": data.draw_odds, "current": data.draw_odds},
                "away": {"opening": data.away_odds, "current": data.away_odds},
            },
            "OU_25": {
                "over": {"opening": ou_over, "current": ou_over},
                "under": {"opening": ou_under, "current": ou_under},
            },
            "BTTS": {
                "yes": {"opening": btts_y, "current": btts_y},
                "no": {"opening": btts_n, "current": btts_n},
            },
            "AH": {
                "home_-0.25": {"opening": 1.95, "current": 1.95},
                "away_+0.25": {"opening": 1.95, "current": 1.95},
            },
        },
    }
    return match_id


@router.post("/analyze", response_model=MatchAnalysis)
async def analyze_custom(data: CustomOddsInput):
    """
    กรอกทีม + ค่าน้ำ → ได้การวิเคราะห์ครบ (Fact / Analysis / Value)
    ใช้เมื่อแคปหน้าจอจากเว็บเจ้าอื่นแล้วอยากให้ระบบช่วยประเมิน
    """
    try:
        match_id = _build_temp_match(data)
        return analyze_match(match_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"วิเคราะห์ไม่สำเร็จ: {str(e)}")
