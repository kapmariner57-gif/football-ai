from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from pydantic import BaseModel

from app.models.schemas import MatchAnalysis, MatchSummary, ValueSignal, ConfidenceLevel, MarketOdds
from app.services.analysis_engine import analyze_match
from app.services.data_service import list_matches as get_all_matches, provider_name

router = APIRouter(prefix="/api/matches", tags=["matches"])


class ValueOpportunity(BaseModel):
    match_id: str
    home_team: str
    away_team: str
    competition: str
    kickoff: str
    market: str
    selection: str
    odds: float
    model_prob: float
    implied_prob: float
    edge: float
    value_signal: ValueSignal
    confidence: ConfidenceLevel
    match_summary: str


@router.get("/", response_model=List[MatchSummary])
async def list_matches(
    signal: Optional[str] = Query(None, description="Filter by signal: strong_value, value, slight_value, no_clear_edge"),
    competition: Optional[str] = Query(None, description="Filter by competition name")
):
    """รายการคู่แข่งขันทั้งหมดพร้อมสรุปสั้น ๆ จาก AI + filter ได้"""
    matches = get_all_matches()
    summaries = []

    for m in matches:
        try:
            analysis = analyze_match(m["match_id"])
            if signal and analysis.snapshot.main_signal.value != signal:
                continue
            if competition and competition.lower() not in analysis.competition.lower():
                continue
            summaries.append(MatchSummary(
                match_id=analysis.match_id,
                home_team=analysis.home_team,
                away_team=analysis.away_team,
                competition=analysis.competition,
                kickoff=analysis.kickoff,
                status=analysis.status,
                main_signal=analysis.snapshot.main_signal,
                confidence=analysis.snapshot.confidence,
                short_summary=analysis.snapshot.summary[:180] + "..." if len(analysis.snapshot.summary) > 180 else analysis.snapshot.summary,
                model_home_win=analysis.model_probabilities["home"],
                model_draw=analysis.model_probabilities["draw"],
                model_away_win=analysis.model_probabilities["away"]
            ))
        except Exception:
            if signal or competition:
                continue
            summaries.append(MatchSummary(
                match_id=m["match_id"],
                home_team=m["home_team"],
                away_team=m["away_team"],
                competition=m["competition"],
                kickoff=m["kickoff"],
                status=m["status"],
                main_signal=ValueSignal.NO_CLEAR_EDGE,
                confidence=ConfidenceLevel.LOW,
                short_summary="กำลังวิเคราะห์...",
                model_home_win=0.33,
                model_draw=0.33,
                model_away_win=0.34
            ))

    # เรียงตามความแข็งของ signal
    order = {
        ValueSignal.STRONG_VALUE: 0,
        ValueSignal.VALUE: 1,
        ValueSignal.SLIGHT_VALUE: 2,
        ValueSignal.NO_CLEAR_EDGE: 3,
        ValueSignal.AVOID: 4,
    }
    summaries.sort(key=lambda x: order.get(x.main_signal, 99))
    return summaries


@router.get("/value-board", response_model=List[ValueOpportunity])
async def value_board(
    min_edge: float = Query(0.03, description="Minimum edge to include (default 3%)")
):
    """
    Value Board — รวมทุกตลาดจากทุกคู่ที่มี edge ผ่าน threshold
    เรียงจาก edge สูงสุดลงมา
    """
    opportunities = []
    matches = get_all_matches()

    for m in matches:
        try:
            analysis = analyze_match(m["match_id"])
            for market in analysis.markets:
                if market.edge >= min_edge and market.value_signal in (
                    ValueSignal.STRONG_VALUE,
                    ValueSignal.VALUE,
                    ValueSignal.SLIGHT_VALUE,
                ):
                    opportunities.append(ValueOpportunity(
                        match_id=analysis.match_id,
                        home_team=analysis.home_team,
                        away_team=analysis.away_team,
                        competition=analysis.competition,
                        kickoff=analysis.kickoff,
                        market=market.market.value,
                        selection=market.selection,
                        odds=market.odds,
                        model_prob=market.model_prob,
                        implied_prob=market.implied_prob,
                        edge=market.edge,
                        value_signal=market.value_signal,
                        confidence=analysis.snapshot.confidence,
                        match_summary=analysis.snapshot.summary[:120]
                    ))
        except Exception:
            continue

    # เรียง edge จากมากไปน้อย
    opportunities.sort(key=lambda x: x.edge, reverse=True)
    return opportunities


@router.get("/{match_id}", response_model=MatchAnalysis)
async def get_match_analysis(match_id: str):
    """วิเคราะห์คู่แข่งขันแบบละเอียดครบทุกชั้น (Fact / Analysis / Uncertainty / Value)"""
    try:
        return analyze_match(match_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis error: {str(e)}")
