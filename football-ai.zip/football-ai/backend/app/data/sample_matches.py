"""
Sample high-quality match data for demonstration.
In production → replace with real API feeds (API-Football, The Odds API, Opta, StatsBomb).
"""

from datetime import datetime, timedelta

SAMPLE_MATCHES = {
    "pl_001": {
        "match_id": "pl_001",
        "home_team": "Arsenal",
        "away_team": "Manchester City",
        "competition": "Premier League",
        "kickoff": (datetime.utcnow() + timedelta(days=2)).strftime("%Y-%m-%d %H:%M UTC"),
        "status": "scheduled",
        "venue": "Emirates Stadium",
        "home_form": {"last_5": ["W", "W", "D", "W", "W"], "goals_scored": 12, "goals_conceded": 4, "xg_for": 11.8, "xg_against": 5.1, "points": 13},
        "away_form": {"last_5": ["W", "D", "W", "W", "L"], "goals_scored": 11, "goals_conceded": 6, "xg_for": 10.9, "xg_against": 6.4, "points": 10},
        "key_players": {
            "home": [
                {"name": "Bukayo Saka", "position": "RW", "status": "available", "impact": "high"},
                {"name": "Martin Ødegaard", "position": "AM", "status": "available", "impact": "high"},
                {"name": "William Saliba", "position": "CB", "status": "available", "impact": "high"},
                {"name": "Kai Havertz", "position": "FW", "status": "doubtful", "impact": "medium"},
            ],
            "away": [
                {"name": "Erling Haaland", "position": "ST", "status": "available", "impact": "high"},
                {"name": "Kevin De Bruyne", "position": "CM", "status": "injured", "impact": "high"},
                {"name": "Rodri", "position": "DM", "status": "available", "impact": "high"},
                {"name": "Phil Foden", "position": "AM", "status": "available", "impact": "high"},
            ]
        },
        "h2h": {"last_5": ["Arsenal 1-0 Man City", "Man City 0-0 Arsenal", "Arsenal 1-1 Man City", "Man City 4-1 Arsenal", "Arsenal 1-2 Man City"], "home_wins": 1, "draws": 2, "away_wins": 2},
        "situational": [
            "Arsenal มีวันพักมากกว่า 1 วัน",
            "Man City เพิ่งเล่น Champions League midweek",
            "Emirates เป็นหนึ่งในสนามที่แข็งแกร่งที่สุดของ Arsenal",
            "De Bruyne ยังไม่กลับจากอาการบาดเจ็บ"
        ],
        "raw_stats": {"home_avg_xg": 2.15, "away_avg_xg": 1.95, "home_avg_xga": 0.85, "away_avg_xga": 1.10, "home_possession": 58.2, "away_possession": 61.5, "home_ppda": 9.8, "away_ppda": 11.2},
        "odds": {
            "1X2": {"home": {"opening": 2.40, "current": 2.25}, "draw": {"opening": 3.40, "current": 3.50}, "away": {"opening": 2.90, "current": 3.10}},
            "OU_25": {"over": {"opening": 1.75, "current": 1.80}, "under": {"opening": 2.15, "current": 2.05}},
            "BTTS": {"yes": {"opening": 1.70, "current": 1.72}, "no": {"opening": 2.15, "current": 2.10}},
            "AH": {"home_-0.25": {"opening": 1.95, "current": 1.90}, "away_+0.25": {"opening": 1.95, "current": 2.00}}
        }
    },
    "pl_002": {
        "match_id": "pl_002",
        "home_team": "Liverpool",
        "away_team": "Chelsea",
        "competition": "Premier League",
        "kickoff": (datetime.utcnow() + timedelta(days=3)).strftime("%Y-%m-%d %H:%M UTC"),
        "status": "scheduled",
        "venue": "Anfield",
        "home_form": {"last_5": ["W", "W", "W", "D", "W"], "goals_scored": 14, "goals_conceded": 5, "xg_for": 13.2, "xg_against": 6.1, "points": 13},
        "away_form": {"last_5": ["L", "W", "D", "W", "D"], "goals_scored": 8, "goals_conceded": 7, "xg_for": 9.4, "xg_against": 8.2, "points": 8},
        "key_players": {
            "home": [
                {"name": "Mohamed Salah", "position": "RW", "status": "available", "impact": "high"},
                {"name": "Virgil van Dijk", "position": "CB", "status": "available", "impact": "high"},
                {"name": "Alexis Mac Allister", "position": "CM", "status": "available", "impact": "medium"},
                {"name": "Darwin Núñez", "position": "ST", "status": "available", "impact": "medium"},
            ],
            "away": [
                {"name": "Cole Palmer", "position": "AM", "status": "available", "impact": "high"},
                {"name": "Enzo Fernández", "position": "CM", "status": "available", "impact": "medium"},
                {"name": "Reece James", "position": "RB", "status": "injured", "impact": "high"},
                {"name": "Nicolas Jackson", "position": "ST", "status": "available", "impact": "medium"},
            ]
        },
        "h2h": {"last_5": ["Liverpool 4-1 Chelsea", "Chelsea 1-1 Liverpool", "Liverpool 1-1 Chelsea", "Chelsea 0-2 Liverpool", "Liverpool 0-0 Chelsea"], "home_wins": 2, "draws": 3, "away_wins": 0},
        "situational": [
            "Anfield เป็นหนึ่งในสนามที่ยากที่สุดในลีก",
            "Chelsea มีปัญหาที่ฟูลแบ็กขวา (James บาดเจ็บ)",
            "Liverpool ฟอร์มบ้านแข็งแกร่งมากในฤดูกาลนี้",
            "Chelsea ยังปรับระบบเกมไม่นิ่ง"
        ],
        "raw_stats": {"home_avg_xg": 2.40, "away_avg_xg": 1.65, "home_avg_xga": 0.95, "away_avg_xga": 1.35, "home_possession": 59.8, "away_possession": 55.1, "home_ppda": 8.9, "away_ppda": 12.4},
        "odds": {
            "1X2": {"home": {"opening": 1.70, "current": 1.65}, "draw": {"opening": 3.80, "current": 3.90}, "away": {"opening": 4.80, "current": 5.00}},
            "OU_25": {"over": {"opening": 1.65, "current": 1.68}, "under": {"opening": 2.25, "current": 2.20}},
            "BTTS": {"yes": {"opening": 1.65, "current": 1.70}, "no": {"opening": 2.20, "current": 2.15}},
            "AH": {"home_-0.75": {"opening": 1.90, "current": 1.85}, "away_+0.75": {"opening": 2.00, "current": 2.05}}
        }
    },
    "pl_003": {
        "match_id": "pl_003",
        "home_team": "Tottenham",
        "away_team": "Aston Villa",
        "competition": "Premier League",
        "kickoff": (datetime.utcnow() + timedelta(days=1)).strftime("%Y-%m-%d %H:%M UTC"),
        "status": "scheduled",
        "venue": "Tottenham Hotspur Stadium",
        "home_form": {"last_5": ["L", "W", "L", "D", "W"], "goals_scored": 7, "goals_conceded": 9, "xg_for": 8.1, "xg_against": 9.5, "points": 7},
        "away_form": {"last_5": ["W", "W", "D", "W", "D"], "goals_scored": 10, "goals_conceded": 5, "xg_for": 9.8, "xg_against": 5.9, "points": 11},
        "key_players": {
            "home": [
                {"name": "Son Heung-min", "position": "FW", "status": "available", "impact": "high"},
                {"name": "James Maddison", "position": "AM", "status": "doubtful", "impact": "high"},
                {"name": "Cristian Romero", "position": "CB", "status": "available", "impact": "high"},
                {"name": "Destiny Udogie", "position": "LB", "status": "available", "impact": "medium"},
            ],
            "away": [
                {"name": "Ollie Watkins", "position": "ST", "status": "available", "impact": "high"},
                {"name": "John McGinn", "position": "CM", "status": "available", "impact": "medium"},
                {"name": "Emiliano Martínez", "position": "GK", "status": "available", "impact": "high"},
                {"name": "Boubacar Kamara", "position": "DM", "status": "injured", "impact": "medium"},
            ]
        },
        "h2h": {"last_5": ["Tottenham 1-2 Aston Villa", "Aston Villa 1-0 Tottenham", "Tottenham 3-1 Aston Villa", "Aston Villa 2-1 Tottenham", "Tottenham 0-2 Aston Villa"], "home_wins": 1, "draws": 0, "away_wins": 4},
        "situational": [
            "Tottenham มีปัญหาความสม่ำเสมอในเกมบ้าน",
            "Aston Villa ฟอร์มเยือนดีและเล่นแบบมีระบบ",
            "Maddison มีสถานะ doubtful ซึ่งส่งผลต่อ creativity",
            "Villa มักเล่นได้ดีเมื่อเป็น underdog"
        ],
        "raw_stats": {"home_avg_xg": 1.55, "away_avg_xg": 1.70, "home_avg_xga": 1.60, "away_avg_xga": 1.05, "home_possession": 54.0, "away_possession": 52.5, "home_ppda": 11.5, "away_ppda": 10.8},
        "odds": {
            "1X2": {"home": {"opening": 2.10, "current": 2.20}, "draw": {"opening": 3.40, "current": 3.30}, "away": {"opening": 3.40, "current": 3.20}},
            "OU_25": {"over": {"opening": 1.80, "current": 1.85}, "under": {"opening": 2.05, "current": 2.00}},
            "BTTS": {"yes": {"opening": 1.65, "current": 1.68}, "no": {"opening": 2.20, "current": 2.15}},
            "AH": {"home_-0.25": {"opening": 1.95, "current": 2.05}, "away_+0.25": {"opening": 1.95, "current": 1.85}}
        }
    },
    "pl_004": {
        "match_id": "pl_004",
        "home_team": "Manchester United",
        "away_team": "Newcastle",
        "competition": "Premier League",
        "kickoff": (datetime.utcnow() + timedelta(days=2, hours=3)).strftime("%Y-%m-%d %H:%M UTC"),
        "status": "scheduled",
        "venue": "Old Trafford",
        "home_form": {"last_5": ["W", "L", "W", "D", "L"], "goals_scored": 8, "goals_conceded": 8, "xg_for": 8.5, "xg_against": 8.9, "points": 7},
        "away_form": {"last_5": ["W", "W", "L", "W", "D"], "goals_scored": 11, "goals_conceded": 6, "xg_for": 10.2, "xg_against": 6.8, "points": 10},
        "key_players": {
            "home": [
                {"name": "Bruno Fernandes", "position": "AM", "status": "available", "impact": "high"},
                {"name": "Marcus Rashford", "position": "LW", "status": "available", "impact": "medium"},
                {"name": "Lisandro Martínez", "position": "CB", "status": "injured", "impact": "high"},
                {"name": "Kobbie Mainoo", "position": "CM", "status": "available", "impact": "medium"},
            ],
            "away": [
                {"name": "Alexander Isak", "position": "ST", "status": "available", "impact": "high"},
                {"name": "Bruno Guimarães", "position": "CM", "status": "available", "impact": "high"},
                {"name": "Anthony Gordon", "position": "LW", "status": "available", "impact": "medium"},
                {"name": "Sven Botman", "position": "CB", "status": "doubtful", "impact": "high"},
            ]
        },
        "h2h": {"last_5": ["Man Utd 0-3 Newcastle", "Newcastle 1-0 Man Utd", "Man Utd 3-2 Newcastle", "Newcastle 0-2 Man Utd", "Man Utd 1-1 Newcastle"], "home_wins": 2, "draws": 1, "away_wins": 2},
        "situational": [
            "Man United ยังไม่เสถียรในเกมรับ",
            "Newcastle ฟอร์มดีและมีคุณภาพโจมตีสูง",
            "Martínez บาดเจ็บส่งผลต่อเสถียรภาพของแนวรับ",
            "Old Trafford ไม่ได้เป็นปราการที่แข็งแกร่งเหมือนเคย"
        ],
        "raw_stats": {"home_avg_xg": 1.60, "away_avg_xg": 1.85, "home_avg_xga": 1.55, "away_avg_xga": 1.15, "home_possession": 53.0, "away_possession": 51.5, "home_ppda": 12.1, "away_ppda": 10.5},
        "odds": {
            "1X2": {"home": {"opening": 2.50, "current": 2.60}, "draw": {"opening": 3.40, "current": 3.40}, "away": {"opening": 2.70, "current": 2.55}},
            "OU_25": {"over": {"opening": 1.70, "current": 1.72}, "under": {"opening": 2.15, "current": 2.12}},
            "BTTS": {"yes": {"opening": 1.60, "current": 1.62}, "no": {"opening": 2.30, "current": 2.25}},
            "AH": {"home_-0.00": {"opening": 1.95, "current": 2.05}, "away_+0.00": {"opening": 1.95, "current": 1.85}}
        }
    },
    "pl_005": {
        "match_id": "pl_005",
        "home_team": "Brighton",
        "away_team": "West Ham",
        "competition": "Premier League",
        "kickoff": (datetime.utcnow() + timedelta(days=4)).strftime("%Y-%m-%d %H:%M UTC"),
        "status": "scheduled",
        "venue": "Amex Stadium",
        "home_form": {"last_5": ["W", "D", "W", "W", "L"], "goals_scored": 10, "goals_conceded": 7, "xg_for": 10.5, "xg_against": 7.8, "points": 10},
        "away_form": {"last_5": ["L", "L", "W", "D", "L"], "goals_scored": 5, "goals_conceded": 10, "xg_for": 6.2, "xg_against": 11.0, "points": 4},
        "key_players": {
            "home": [
                {"name": "Kaoru Mitoma", "position": "LW", "status": "available", "impact": "high"},
                {"name": "João Pedro", "position": "ST", "status": "available", "impact": "high"},
                {"name": "Pascal Groß", "position": "CM", "status": "available", "impact": "medium"},
                {"name": "Lewis Dunk", "position": "CB", "status": "available", "impact": "medium"},
            ],
            "away": [
                {"name": "Jarrod Bowen", "position": "RW", "status": "available", "impact": "high"},
                {"name": "Lucas Paquetá", "position": "AM", "status": "available", "impact": "medium"},
                {"name": "Mohammed Kudus", "position": "AM", "status": "injured", "impact": "high"},
                {"name": "Nayef Aguerd", "position": "CB", "status": "available", "impact": "medium"},
            ]
        },
        "h2h": {"last_5": ["Brighton 1-3 West Ham", "West Ham 0-0 Brighton", "Brighton 4-0 West Ham", "West Ham 3-1 Brighton", "Brighton 2-0 West Ham"], "home_wins": 2, "draws": 1, "away_wins": 2},
        "situational": [
            "Brighton เล่นเกมครองบอลและสร้างโอกาสได้ดี",
            "West Ham ฟอร์มตกและขาด Kudus",
            "Amex Stadium เป็นสนามที่ Brighton มักทำผลงานได้ดี",
            "West Ham มีปัญหาในการสร้างเกมรุกเมื่อขาดผู้เล่นหลัก"
        ],
        "raw_stats": {"home_avg_xg": 1.90, "away_avg_xg": 1.15, "home_avg_xga": 1.25, "away_avg_xga": 1.80, "home_possession": 58.5, "away_possession": 44.0, "home_ppda": 10.2, "away_ppda": 14.5},
        "odds": {
            "1X2": {"home": {"opening": 1.75, "current": 1.70}, "draw": {"opening": 3.70, "current": 3.80}, "away": {"opening": 4.50, "current": 4.80}},
            "OU_25": {"over": {"opening": 1.75, "current": 1.78}, "under": {"opening": 2.10, "current": 2.05}},
            "BTTS": {"yes": {"opening": 1.75, "current": 1.80}, "no": {"opening": 2.05, "current": 2.00}},
            "AH": {"home_-0.75": {"opening": 1.95, "current": 1.90}, "away_+0.75": {"opening": 1.95, "current": 2.00}}
        }
    },
    "laliga_001": {
        "match_id": "laliga_001",
        "home_team": "Real Madrid",
        "away_team": "Barcelona",
        "competition": "La Liga",
        "kickoff": (datetime.utcnow() + timedelta(days=4)).strftime("%Y-%m-%d %H:%M UTC"),
        "status": "scheduled",
        "venue": "Santiago Bernabéu",
        "home_form": {"last_5": ["W", "W", "W", "W", "D"], "goals_scored": 15, "goals_conceded": 4, "xg_for": 14.1, "xg_against": 5.2, "points": 13},
        "away_form": {"last_5": ["W", "W", "D", "W", "W"], "goals_scored": 13, "goals_conceded": 5, "xg_for": 12.8, "xg_against": 5.8, "points": 13},
        "key_players": {
            "home": [
                {"name": "Vinícius Júnior", "position": "LW", "status": "available", "impact": "high"},
                {"name": "Jude Bellingham", "position": "AM", "status": "available", "impact": "high"},
                {"name": "Kylian Mbappé", "position": "ST", "status": "available", "impact": "high"},
                {"name": "Antonio Rüdiger", "position": "CB", "status": "available", "impact": "high"},
            ],
            "away": [
                {"name": "Robert Lewandowski", "position": "ST", "status": "available", "impact": "high"},
                {"name": "Pedri", "position": "CM", "status": "available", "impact": "high"},
                {"name": "Lamine Yamal", "position": "RW", "status": "available", "impact": "high"},
                {"name": "Frenkie de Jong", "position": "CM", "status": "doubtful", "impact": "high"},
            ]
        },
        "h2h": {"last_5": ["Real Madrid 3-2 Barcelona", "Barcelona 1-2 Real Madrid", "Real Madrid 0-4 Barcelona", "Barcelona 2-1 Real Madrid", "Real Madrid 3-1 Barcelona"], "home_wins": 3, "draws": 0, "away_wins": 2},
        "situational": [
            "El Clásico — ความกดดันสูงมากทั้งสองฝ่าย",
            "Real Madrid ฟอร์มบ้านยอดเยี่ยม",
            "Barcelona มีปัญหาที่ midfield หาก de Jong ไม่พร้อม",
            "ทั้งสองทีมมีคุณภาพโจมตีสูงมาก → โอกาสประตูสูง"
        ],
        "raw_stats": {"home_avg_xg": 2.55, "away_avg_xg": 2.30, "home_avg_xga": 0.90, "away_avg_xga": 1.05, "home_possession": 57.0, "away_possession": 64.5, "home_ppda": 10.2, "away_ppda": 9.1},
        "odds": {
            "1X2": {"home": {"opening": 2.20, "current": 2.15}, "draw": {"opening": 3.60, "current": 3.70}, "away": {"opening": 3.10, "current": 3.20}},
            "OU_25": {"over": {"opening": 1.50, "current": 1.48}, "under": {"opening": 2.60, "current": 2.65}},
            "BTTS": {"yes": {"opening": 1.45, "current": 1.42}, "no": {"opening": 2.70, "current": 2.80}},
            "AH": {"home_-0.25": {"opening": 1.90, "current": 1.88}, "away_+0.25": {"opening": 2.00, "current": 2.02}}
        }
    },
    "laliga_002": {
        "match_id": "laliga_002",
        "home_team": "Atlético Madrid",
        "away_team": "Sevilla",
        "competition": "La Liga",
        "kickoff": (datetime.utcnow() + timedelta(days=3)).strftime("%Y-%m-%d %H:%M UTC"),
        "status": "scheduled",
        "venue": "Cívitas Metropolitano",
        "home_form": {"last_5": ["W", "W", "D", "W", "W"], "goals_scored": 9, "goals_conceded": 3, "xg_for": 9.5, "xg_against": 4.2, "points": 13},
        "away_form": {"last_5": ["L", "D", "W", "L", "D"], "goals_scored": 5, "goals_conceded": 8, "xg_for": 6.0, "xg_against": 8.5, "points": 5},
        "key_players": {
            "home": [
                {"name": "Antoine Griezmann", "position": "FW", "status": "available", "impact": "high"},
                {"name": "Álvaro Morata", "position": "ST", "status": "available", "impact": "medium"},
                {"name": "Koke", "position": "CM", "status": "available", "impact": "medium"},
                {"name": "José María Giménez", "position": "CB", "status": "available", "impact": "high"},
            ],
            "away": [
                {"name": "Youssef En-Nesyri", "position": "ST", "status": "available", "impact": "high"},
                {"name": "Ivan Rakitić", "position": "CM", "status": "available", "impact": "medium"},
                {"name": "Jesús Navas", "position": "RB", "status": "doubtful", "impact": "medium"},
                {"name": "Sergio Ramos", "position": "CB", "status": "available", "impact": "medium"},
            ]
        },
        "h2h": {"last_5": ["Atlético 1-0 Sevilla", "Sevilla 0-2 Atlético", "Atlético 2-1 Sevilla", "Sevilla 1-1 Atlético", "Atlético 3-0 Sevilla"], "home_wins": 3, "draws": 1, "away_wins": 0},
        "situational": [
            "Atlético แข็งแกร่งมากในเกมบ้านและเกมรับ",
            "Sevilla ฟอร์มไม่ดีและมีปัญหาความสม่ำเสมอ",
            "Metropolitano เป็นสนามที่ยากสำหรับทีมเยือน",
            "Atlético มักชนะเกมลักษณะนี้ด้วยสกอร์ต่ำ"
        ],
        "raw_stats": {"home_avg_xg": 1.70, "away_avg_xg": 1.10, "home_avg_xga": 0.75, "away_avg_xga": 1.50, "home_possession": 52.0, "away_possession": 48.5, "home_ppda": 11.8, "away_ppda": 13.2},
        "odds": {
            "1X2": {"home": {"opening": 1.55, "current": 1.50}, "draw": {"opening": 4.00, "current": 4.20}, "away": {"opening": 6.00, "current": 6.50}},
            "OU_25": {"over": {"opening": 2.00, "current": 2.05}, "under": {"opening": 1.85, "current": 1.80}},
            "BTTS": {"yes": {"opening": 2.10, "current": 2.15}, "no": {"opening": 1.70, "current": 1.68}},
            "AH": {"home_-1.00": {"opening": 1.95, "current": 1.90}, "away_+1.00": {"opening": 1.95, "current": 2.00}}
        }
    },
    "seriea_001": {
        "match_id": "seriea_001",
        "home_team": "Inter",
        "away_team": "Juventus",
        "competition": "Serie A",
        "kickoff": (datetime.utcnow() + timedelta(days=2, hours=6)).strftime("%Y-%m-%d %H:%M UTC"),
        "status": "scheduled",
        "venue": "San Siro",
        "home_form": {"last_5": ["W", "W", "W", "D", "W"], "goals_scored": 13, "goals_conceded": 4, "xg_for": 12.5, "xg_against": 5.0, "points": 13},
        "away_form": {"last_5": ["W", "D", "W", "W", "D"], "goals_scored": 9, "goals_conceded": 4, "xg_for": 9.0, "xg_against": 5.5, "points": 11},
        "key_players": {
            "home": [
                {"name": "Lautaro Martínez", "position": "ST", "status": "available", "impact": "high"},
                {"name": "Nicolò Barella", "position": "CM", "status": "available", "impact": "high"},
                {"name": "Marcus Thuram", "position": "ST", "status": "available", "impact": "high"},
                {"name": "Alessandro Bastoni", "position": "CB", "status": "available", "impact": "high"},
            ],
            "away": [
                {"name": "Dušan Vlahović", "position": "ST", "status": "available", "impact": "high"},
                {"name": "Federico Chiesa", "position": "RW", "status": "available", "impact": "high"},
                {"name": "Manuel Locatelli", "position": "CM", "status": "available", "impact": "medium"},
                {"name": "Bremer", "position": "CB", "status": "injured", "impact": "high"},
            ]
        },
        "h2h": {"last_5": ["Inter 1-0 Juventus", "Juventus 1-1 Inter", "Inter 0-1 Juventus", "Juventus 0-1 Inter", "Inter 1-1 Juventus"], "home_wins": 2, "draws": 2, "away_wins": 1},
        "situational": [
            "Derby d'Italia — ความสำคัญสูงมาก",
            "Inter ฟอร์มดีที่สุดในลีกตอนนี้",
            "Juventus ขาด Bremer ซึ่งเป็นแกนหลักของแนวรับ",
            "San Siro เป็นสนามที่ Inter มักครองเกมได้ดี"
        ],
        "raw_stats": {"home_avg_xg": 2.20, "away_avg_xg": 1.55, "home_avg_xga": 0.85, "away_avg_xga": 1.00, "home_possession": 56.5, "away_possession": 50.0, "home_ppda": 9.5, "away_ppda": 12.0},
        "odds": {
            "1X2": {"home": {"opening": 1.90, "current": 1.85}, "draw": {"opening": 3.40, "current": 3.50}, "away": {"opening": 4.20, "current": 4.40}},
            "OU_25": {"over": {"opening": 2.00, "current": 2.05}, "under": {"opening": 1.85, "current": 1.80}},
            "BTTS": {"yes": {"opening": 1.90, "current": 1.95}, "no": {"opening": 1.90, "current": 1.85}},
            "AH": {"home_-0.50": {"opening": 1.95, "current": 1.90}, "away_+0.50": {"opening": 1.95, "current": 2.00}}
        }
    },
    "bundes_001": {
        "match_id": "bundes_001",
        "home_team": "Bayern Munich",
        "away_team": "Borussia Dortmund",
        "competition": "Bundesliga",
        "kickoff": (datetime.utcnow() + timedelta(days=5)).strftime("%Y-%m-%d %H:%M UTC"),
        "status": "scheduled",
        "venue": "Allianz Arena",
        "home_form": {"last_5": ["W", "W", "W", "W", "W"], "goals_scored": 18, "goals_conceded": 5, "xg_for": 16.5, "xg_against": 5.8, "points": 15},
        "away_form": {"last_5": ["W", "L", "W", "D", "W"], "goals_scored": 12, "goals_conceded": 8, "xg_for": 11.5, "xg_against": 8.0, "points": 10},
        "key_players": {
            "home": [
                {"name": "Harry Kane", "position": "ST", "status": "available", "impact": "high"},
                {"name": "Jamal Musiala", "position": "AM", "status": "available", "impact": "high"},
                {"name": "Leroy Sané", "position": "RW", "status": "available", "impact": "high"},
                {"name": "Manuel Neuer", "position": "GK", "status": "available", "impact": "high"},
            ],
            "away": [
                {"name": "Julian Brandt", "position": "AM", "status": "available", "impact": "high"},
                {"name": "Niclas Füllkrug", "position": "ST", "status": "available", "impact": "high"},
                {"name": "Marcel Sabitzer", "position": "CM", "status": "available", "impact": "medium"},
                {"name": "Nico Schlotterbeck", "position": "CB", "status": "available", "impact": "high"},
            ]
        },
        "h2h": {"last_5": ["Bayern 4-0 Dortmund", "Dortmund 2-2 Bayern", "Bayern 3-1 Dortmund", "Dortmund 0-4 Bayern", "Bayern 2-2 Dortmund"], "home_wins": 3, "draws": 2, "away_wins": 0},
        "situational": [
            "Der Klassiker — เกมใหญ่ที่สุดของเยอรมัน",
            "Bayern ฟอร์มโหดและยิงประตูได้มหาศาล",
            "Dortmund มักมีปัญหาเมื่อเจอ Bayern ที่ Allianz",
            "เกมนี้มีแนวโน้มประตูสูงมาก"
        ],
        "raw_stats": {"home_avg_xg": 2.90, "away_avg_xg": 1.95, "home_avg_xga": 0.95, "away_avg_xga": 1.40, "home_possession": 62.0, "away_possession": 55.0, "home_ppda": 8.5, "away_ppda": 10.8},
        "odds": {
            "1X2": {"home": {"opening": 1.45, "current": 1.42}, "draw": {"opening": 4.80, "current": 5.00}, "away": {"opening": 6.00, "current": 6.50}},
            "OU_25": {"over": {"opening": 1.40, "current": 1.38}, "under": {"opening": 3.00, "current": 3.10}},
            "BTTS": {"yes": {"opening": 1.55, "current": 1.52}, "no": {"opening": 2.45, "current": 2.50}},
            "AH": {"home_-1.50": {"opening": 1.90, "current": 1.85}, "away_+1.50": {"opening": 2.00, "current": 2.05}}
        }
    },
}


def get_all_matches():
    return list(SAMPLE_MATCHES.values())


def get_match(match_id: str):
    return SAMPLE_MATCHES.get(match_id)
