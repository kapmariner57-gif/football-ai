"""
Central Configuration
"""

import os

# แหล่งข้อมูล: "sample" | "api"
DATA_PROVIDER = os.getenv("DATA_PROVIDER", "sample")
FOOTBALL_DATA_API_TOKEN = os.getenv("FOOTBALL_DATA_API_TOKEN", "")

# API Keys (ตั้งผ่าน environment variable เท่านั้น — อย่า hardcode)
API_FOOTBALL_KEY = os.getenv("API_FOOTBALL_KEY", "")
ODDS_API_KEY = os.getenv("ODDS_API_KEY", "")

# Value Detection thresholds (conservative)
VALUE_THRESHOLDS = {
    "strong_value": 0.08,   # ≥ 8%
    "value": 0.05,          # ≥ 5%
    "slight_value": 0.03,   # ≥ 3%
    "avoid": -0.07,         # ≤ -7%
}

# ลีกที่รองรับ (สำหรับ API mode)
SUPPORTED_LEAGUES = {
    "Premier League": 39,
    "La Liga": 140,
    "Serie A": 135,
    "Bundesliga": 78,
    "Ligue 1": 61,
}

# App
APP_NAME = "Football AI Intelligence"
APP_VERSION = "1.1.0"
