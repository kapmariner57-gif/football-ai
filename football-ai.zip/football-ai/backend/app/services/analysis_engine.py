"""
Match Intelligence & Value Detection Engine v2

หลักการสำคัญ:
1. แยก Fact / Analysis / Uncertainty ชัดเจน
2. ใช้ Poisson model ประเมินความน่าจะเป็น
3. เปรียบเทียบกับ market implied probability (ถอด vig)
4. Conservative value threshold — แสดง value เฉพาะเมื่อ edge ชัด
5. กล้าบอก "ยังไม่มีโอกาสที่ชัดเจน"
"""

from datetime import datetime
from typing import Dict, List, Any, Tuple
import math

from app.models.schemas import (
    MatchAnalysis, AISnapshot, FactItem, AnalysisPoint, UncertaintyNote,
    MarketOdds, TeamForm, PlayerStatus, OddsMovement,
    ConfidenceLevel, ValueSignal, MarketType
)
from app.services.data_service import get_match_data as get_match


# ====================== Math Helpers ======================

def poisson_pmf(k: int, lam: float) -> float:
    """P(X=k) for Poisson(lam)"""
    if lam <= 0:
        return 1.0 if k == 0 else 0.0
    return math.exp(-lam) * (lam ** k) / math.factorial(k)


def poisson_match_probs(home_exp: float, away_exp: float, max_goals: int = 8) -> Dict[str, float]:
    """คำนวณ 1X2 + Over/Under + BTTS จาก Poisson independent model"""
    home_win = draw = away_win = 0.0
    over25 = under25 = btts_yes = btts_no = 0.0
    score_matrix = {}

    for i in range(max_goals + 1):
        for j in range(max_goals + 1):
            p = poisson_pmf(i, home_exp) * poisson_pmf(j, away_exp)
            score_matrix[(i, j)] = p
            if i > j:
                home_win += p
            elif i == j:
                draw += p
            else:
                away_win += p
            if i + j > 2.5:
                over25 += p
            else:
                under25 += p
            if i > 0 and j > 0:
                btts_yes += p
            else:
                btts_no += p

    total = home_win + draw + away_win
    return {
        "home": home_win / total,
        "draw": draw / total,
        "away": away_win / total,
        "over25": over25,
        "under25": under25,
        "btts_yes": btts_yes,
        "btts_no": btts_no,
        "score_matrix": score_matrix,
        "home_exp": home_exp,
        "away_exp": away_exp
    }


def remove_vig(probs: List[float]) -> List[float]:
    total = sum(probs)
    if total == 0:
        return probs
    return [p / total for p in probs]


def odds_to_prob(odds: float) -> float:
    if odds <= 1.0:
        return 0.0
    return 1.0 / odds


def calculate_edge(model_prob: float, implied_prob: float) -> float:
    return round(model_prob - implied_prob, 4)


def determine_value_signal(edge: float, confidence: ConfidenceLevel) -> ValueSignal:
    if confidence == ConfidenceLevel.INSUFFICIENT:
        return ValueSignal.NO_CLEAR_EDGE
    if edge >= 0.08 and confidence == ConfidenceLevel.HIGH:
        return ValueSignal.STRONG_VALUE
    if edge >= 0.05 and confidence in (ConfidenceLevel.HIGH, ConfidenceLevel.MEDIUM):
        return ValueSignal.VALUE
    if edge >= 0.03:
        return ValueSignal.SLIGHT_VALUE
    if edge <= -0.07:
        return ValueSignal.AVOID
    return ValueSignal.NO_CLEAR_EDGE


# ====================== Core Model ======================

def compute_expected_goals(match: Dict[str, Any]) -> Tuple[float, float, ConfidenceLevel]:
    """
    คำนวณ expected goals ของทั้งสองทีมโดยรวมหลายปัจจัย
    """
    home_xg = match["raw_stats"]["home_avg_xg"]
    away_xg = match["raw_stats"]["away_avg_xg"]
    home_xga = match["raw_stats"]["home_avg_xga"]
    away_xga = match["raw_stats"]["away_avg_xga"]

    # Base expected goals (attack vs defence)
    home_exp = (home_xg * 0.55 + away_xga * 0.45)
    away_exp = (away_xg * 0.55 + home_xga * 0.45)

    # Home advantage
    home_exp *= 1.10
    away_exp *= 0.95

    # Form adjustment (points in last 5)
    home_pts = match["home_form"]["points"]
    away_pts = match["away_form"]["points"]
    form_factor = (home_pts - away_pts) / 15.0
    home_exp *= (1.0 + form_factor * 0.12)
    away_exp *= (1.0 - form_factor * 0.08)

    # Key player impact
    confidence = ConfidenceLevel.HIGH
    for p in match["key_players"]["home"]:
        if p["status"] in ("injured", "suspended") and p["impact"] == "high":
            home_exp *= 0.88
            confidence = ConfidenceLevel.MEDIUM
        elif p["status"] == "doubtful" and p["impact"] == "high":
            home_exp *= 0.94
            confidence = ConfidenceLevel.MEDIUM

    for p in match["key_players"]["away"]:
        if p["status"] in ("injured", "suspended") and p["impact"] == "high":
            away_exp *= 0.88
            confidence = ConfidenceLevel.MEDIUM
        elif p["status"] == "doubtful" and p["impact"] == "high":
            away_exp *= 0.94
            confidence = ConfidenceLevel.MEDIUM

    # Rest / congestion (simple heuristic from situational)
    situational_text = " ".join(match.get("situational", [])).lower()
    if "พักมากกว่า" in situational_text or "rest" in situational_text:
        home_exp *= 1.03
    if "champions league" in situational_text or "midweek" in situational_text:
        if "city" in match["away_team"].lower() or "madrid" in match["away_team"].lower():
            away_exp *= 0.96

    # Floor / ceiling
    home_exp = max(0.6, min(3.8, home_exp))
    away_exp = max(0.5, min(3.5, away_exp))

    return round(home_exp, 3), round(away_exp, 3), confidence


def compute_model_probabilities(match: Dict[str, Any]) -> Dict[str, Any]:
    home_exp, away_exp, conf = compute_expected_goals(match)
    probs = poisson_match_probs(home_exp, away_exp)
    probs["confidence"] = conf
    return probs


# ====================== Layers ======================

def build_facts(match: Dict[str, Any]) -> List[FactItem]:
    facts = []
    hf = match["home_form"]
    af = match["away_form"]

    facts.append(FactItem(
        category="Form",
        text=f"{match['home_team']} 5 นัดล่าสุด: {''.join(hf['last_5'])} | {hf['points']} แต้ม | ยิง {hf['goals_scored']} เสีย {hf['goals_conceded']}",
        source="official_results"
    ))
    facts.append(FactItem(
        category="Form",
        text=f"{match['away_team']} 5 นัดล่าสุด: {''.join(af['last_5'])} | {af['points']} แต้ม | ยิง {af['goals_scored']} เสีย {af['goals_conceded']}",
        source="official_results"
    ))
    facts.append(FactItem(
        category="xG",
        text=f"{match['home_team']} xG เฉลี่ย {match['raw_stats']['home_avg_xg']:.2f} | xGA {match['raw_stats']['home_avg_xga']:.2f}",
        source="stats_provider"
    ))
    facts.append(FactItem(
        category="xG",
        text=f"{match['away_team']} xG เฉลี่ย {match['raw_stats']['away_avg_xg']:.2f} | xGA {match['raw_stats']['away_avg_xga']:.2f}",
        source="stats_provider"
    ))

    for side, team in [("home", match["home_team"]), ("away", match["away_team"])]:
        injured = [p["name"] for p in match["key_players"][side] if p["status"] in ("injured", "suspended")]
        doubtful = [p["name"] for p in match["key_players"][side] if p["status"] == "doubtful"]
        if injured:
            facts.append(FactItem(
                category="Team News",
                text=f"{team} ขาดตัวสำคัญ: {', '.join(injured)}",
                source="club_medical"
            ))
        if doubtful:
            facts.append(FactItem(
                category="Team News",
                text=f"{team} มีผู้เล่นสถานะไม่แน่นอน: {', '.join(doubtful)}",
                source="club_medical",
                confidence=ConfidenceLevel.MEDIUM
            ))

    h2h = match["h2h"]
    facts.append(FactItem(
        category="H2H",
        text=f"5 นัดล่าสุด: {match['home_team']} ชนะ {h2h['home_wins']} | เสมอ {h2h['draws']} | {match['away_team']} ชนะ {h2h['away_wins']}",
        source="historical"
    ))
    return facts


def build_analysis_points(match: Dict[str, Any], model: Dict[str, Any]) -> List[AnalysisPoint]:
    points = []
    home, away = match["home_team"], match["away_team"]
    diff = model["home_exp"] - model["away_exp"]

    if abs(diff) < 0.25:
        text = f"ทั้งสองทีมมีคุณภาพใกล้เคียงกันมาก (xG ต่างกันเพียง {abs(diff):.2f})"
        conf = ConfidenceLevel.MEDIUM
    elif diff > 0.55:
        text = f"{home} มี edge ชัดเจนในเชิงคุณภาพเกม (expected goals สูงกว่า {diff:.2f})"
        conf = ConfidenceLevel.HIGH
    elif diff > 0.25:
        text = f"{home} มีความได้เปรียบเล็กน้อยถึงปานกลาง"
        conf = ConfidenceLevel.MEDIUM
    elif diff < -0.55:
        text = f"{away} มีคุณภาพเกมที่เหนือกว่าชัดเจน"
        conf = ConfidenceLevel.HIGH
    else:
        text = f"{away} มีความได้เปรียบเล็กน้อย"
        conf = ConfidenceLevel.MEDIUM

    points.append(AnalysisPoint(title="ประเมินคุณภาพโดยรวม", content=text, confidence=conf))

    total_exp = model["home_exp"] + model["away_exp"]
    if total_exp >= 3.1:
        points.append(AnalysisPoint(
            title="แนวโน้มประตู",
            content=f"เกมมีแนวโน้มเปิด (รวม expected goals ≈ {total_exp:.2f}) → โอกาส Over และ BTTS สูง",
            confidence=ConfidenceLevel.MEDIUM
        ))
    elif total_exp <= 2.2:
        points.append(AnalysisPoint(
            title="แนวโน้มประตู",
            content=f"เกมมีแนวโน้มปิด (รวม expected goals ≈ {total_exp:.2f}) → Under น่าสนใจกว่า",
            confidence=ConfidenceLevel.MEDIUM
        ))

    for factor in match.get("situational", []):
        points.append(AnalysisPoint(
            title="ปัจจัยสถานการณ์",
            content=factor,
            confidence=ConfidenceLevel.MEDIUM
        ))

    high_absences = []
    for side, team in [("home", home), ("away", away)]:
        for p in match["key_players"][side]:
            if p["status"] in ("injured", "suspended") and p["impact"] == "high":
                high_absences.append(f"{p['name']} ({team})")
    if high_absences:
        points.append(AnalysisPoint(
            title="ผลกระทบจากการขาดผู้เล่นสำคัญ",
            content=f"ขาดตัวสำคัญ: {', '.join(high_absences)} — ส่งผลต่อคุณภาพเกมอย่างมีนัยสำคัญ",
            confidence=ConfidenceLevel.HIGH
        ))
    return points


def build_uncertainties(match: Dict[str, Any], model: Dict[str, Any]) -> List[UncertaintyNote]:
    notes = []
    for side, team in [("home", match["home_team"]), ("away", match["away_team"])]:
        for p in match["key_players"][side]:
            if p["status"] == "doubtful":
                notes.append(UncertaintyNote(
                    area="Team News",
                    description=f"สถานะของ {p['name']} ({team}) ยังไม่ชัดเจน",
                    impact="high" if p["impact"] == "high" else "medium"
                ))

    total_exp = model["home_exp"] + model["away_exp"]
    if total_exp > 3.3:
        notes.append(UncertaintyNote(
            area="Match Variance",
            description="เกมที่มี expected goals สูงมักมี variance มาก ผลลัพธ์ผันผวนได้ง่าย",
            impact="medium"
        ))

    situational = " ".join(match.get("situational", []))
    if "Clásico" in situational or "ดาร์บี้" in situational or "ความกดดันสูง" in situational:
        notes.append(UncertaintyNote(
            area="Psychological",
            description="เกมใหญ่มีปัจจัยทางจิตวิทยาสูง ทำให้สถิติปกติมีน้ำหนักลดลง",
            impact="high"
        ))

    if not notes:
        notes.append(UncertaintyNote(
            area="General",
            description="ข้อมูลค่อนข้างครบ แต่ฟุตบอลยังมี randomness สูงเสมอ",
            impact="low"
        ))
    return notes


def _ah_cover_prob(score_matrix: dict, line: float, side: str = "home") -> float:
    """
    ความน่าจะเป็นที่ฝั่งนั้น cover Asian Handicap จาก score matrix
    รองรับ quarter lines (-0.25, -0.75 ฯลฯ) แบบ half-win / half-lose
    """
    win = push = lose = 0.0
    is_quarter = abs(abs(line) % 1 - 0.25) < 0.01 or abs(abs(line) % 1 - 0.75) < 0.01

    for (h, a), p in score_matrix.items():
        margin = (h - a) if side == "home" else (a - h)

        if is_quarter:
            # แยกเป็น 2 half-lines
            if line < 0:
                lines = (line + 0.25, line - 0.25)  # -0.25 → 0 และ -0.5
            else:
                lines = (line - 0.25, line + 0.25)
            for ln in lines:
                # สำหรับ home: line ติดลบ = เจ้าบ้านต่อ
                # สำหรับ away: line บวก = ทีมเยือนรับ
                if side == "home":
                    diff = margin + ln
                else:
                    # away_+0.25 → ทีมเยือนได้ +0.25
                    diff = margin + ln if ln > 0 else margin - abs(ln)
                    # ทำให้ consistent: ถ้า key เป็น away_+0.25 แล้ว line=+0.25
                    # away cover เมื่อ (a-h) + 0.25 > 0
                    diff = margin + ln
                if diff > 0:
                    win += p * 0.5
                elif diff == 0:
                    push += p * 0.5
                else:
                    lose += p * 0.5
        else:
            if side == "home":
                diff = margin + line
            else:
                diff = margin + line  # away_+0.5 → margin + 0.5
            if diff > 0:
                win += p
            elif diff == 0:
                push += p
            else:
                lose += p

    total = win + push + lose
    if total <= 0:
        return 0.5
    # win ได้เต็ม, push ได้คืนทุน → นับเป็น 0.5
    return (win + 0.5 * push) / total


def build_markets(match: Dict[str, Any], model: Dict[str, Any]) -> List[MarketOdds]:
    markets = []
    odds_data = match["odds"]
    conf = model.get("confidence", ConfidenceLevel.MEDIUM)
    score_matrix = model.get("score_matrix", {})

    # ----- 1X2 -----
    home_odds = odds_data["1X2"]["home"]["current"]
    draw_odds = odds_data["1X2"]["draw"]["current"]
    away_odds = odds_data["1X2"]["away"]["current"]
    raw = [odds_to_prob(home_odds), odds_to_prob(draw_odds), odds_to_prob(away_odds)]
    fair = remove_vig(raw)

    for sel, model_p, implied, current, opening in [
        ("Home", model["home"], fair[0], home_odds, odds_data["1X2"]["home"]["opening"]),
        ("Draw", model["draw"], fair[1], draw_odds, odds_data["1X2"]["draw"]["opening"]),
        ("Away", model["away"], fair[2], away_odds, odds_data["1X2"]["away"]["opening"]),
    ]:
        edge = calculate_edge(model_p, implied)
        signal = determine_value_signal(edge, conf)
        movement = round(((current - opening) / opening) * 100, 2) if opening else 0
        direction = "shortening" if movement < -1.5 else ("drifting" if movement > 1.5 else "stable")
        markets.append(MarketOdds(
            market=MarketType.MATCH_RESULT,
            selection=sel,
            odds=current,
            implied_prob=round(implied, 4),
            model_prob=round(model_p, 4),
            edge=edge,
            value_signal=signal,
            movements=[OddsMovement(
                bookmaker="Market Avg",
                opening=opening,
                current=current,
                movement=movement,
                direction=direction
            )]
        ))

    # ----- Over/Under 2.5 -----
    over_odds = odds_data["OU_25"]["over"]["current"]
    under_odds = odds_data["OU_25"]["under"]["current"]
    ou_fair = remove_vig([odds_to_prob(over_odds), odds_to_prob(under_odds)])

    for sel, model_p, implied, current, opening in [
        ("Over 2.5", model["over25"], ou_fair[0], over_odds, odds_data["OU_25"]["over"]["opening"]),
        ("Under 2.5", model["under25"], ou_fair[1], under_odds, odds_data["OU_25"]["under"]["opening"]),
    ]:
        edge = calculate_edge(model_p, implied)
        signal = determine_value_signal(edge, conf)
        markets.append(MarketOdds(
            market=MarketType.OVER_UNDER,
            selection=sel,
            odds=current,
            implied_prob=round(implied, 4),
            model_prob=round(model_p, 4),
            edge=edge,
            value_signal=signal,
            movements=[]
        ))

    # ----- BTTS -----
    if "BTTS" in odds_data:
        yes_odds = odds_data["BTTS"]["yes"]["current"]
        no_odds = odds_data["BTTS"]["no"]["current"]
        btts_fair = remove_vig([odds_to_prob(yes_odds), odds_to_prob(no_odds)])
        for sel, model_p, implied, current, opening in [
            ("BTTS Yes", model["btts_yes"], btts_fair[0], yes_odds, odds_data["BTTS"]["yes"]["opening"]),
            ("BTTS No", model["btts_no"], btts_fair[1], no_odds, odds_data["BTTS"]["no"]["opening"]),
        ]:
            edge = calculate_edge(model_p, implied)
            signal = determine_value_signal(edge, conf)
            markets.append(MarketOdds(
                market=MarketType.BTTS,
                selection=sel,
                odds=current,
                implied_prob=round(implied, 4),
                model_prob=round(model_p, 4),
                edge=edge,
                value_signal=signal,
                movements=[]
            ))

    # ----- Asian Handicap (from score matrix) -----
    if "AH" in odds_data and score_matrix:
        for key, val in odds_data["AH"].items():
            parts = key.split("_")
            side = parts[0]  # home / away
            line_str = parts[1] if len(parts) > 1 else "0"
            try:
                line = float(line_str)
            except ValueError:
                continue
            selection = f"{'Home' if side == 'home' else 'Away'} {line_str}"
            current = val["current"]
            opening = val.get("opening", current)

            model_p = _ah_cover_prob(score_matrix, line, side)
            # Cap extreme probabilities to stay conservative
            model_p = max(0.12, min(0.88, model_p))
            implied = odds_to_prob(current)
            edge = calculate_edge(model_p, implied)
            # AH uses slightly stricter confidence because of model uncertainty
            ah_conf = ConfidenceLevel.MEDIUM if conf == ConfidenceLevel.HIGH else conf
            signal = determine_value_signal(edge, ah_conf)

            markets.append(MarketOdds(
                market=MarketType.ASIAN_HANDICAP,
                selection=selection,
                odds=current,
                implied_prob=round(implied, 4),
                model_prob=round(model_p, 4),
                edge=edge,
                value_signal=signal,
                movements=[]
            ))

    # ----- Team Totals (derived from Poisson, synthetic odds for demo) -----
    # Home Over/Under 1.5 and Away Over/Under 1.5
    home_exp = model["home_exp"]
    away_exp = model["away_exp"]

    def team_over_prob(exp: float, line: float = 1.5) -> float:
        # P(goals > line) approx for Poisson
        # For 1.5 → P(2+) = 1 - P(0) - P(1)
        p0 = math.exp(-exp)
        p1 = exp * p0
        return 1.0 - p0 - p1

    for team_label, exp, prefix in [
        ("Home", home_exp, "Home"),
        ("Away", away_exp, "Away"),
    ]:
        over_p = team_over_prob(exp, 1.5)
        under_p = 1.0 - over_p
        # Synthetic fair-ish odds for prototype (in production use real TT odds)
        # Assume book margin ~5%
        over_odds_syn = round(1.0 / (over_p * 0.95), 2) if over_p > 0.05 else 9.0
        under_odds_syn = round(1.0 / (under_p * 0.95), 2) if under_p > 0.05 else 9.0
        over_odds_syn = max(1.25, min(6.0, over_odds_syn))
        under_odds_syn = max(1.25, min(6.0, under_odds_syn))

        for sel, model_p, odds_val in [
            (f"{prefix} Over 1.5", over_p, over_odds_syn),
            (f"{prefix} Under 1.5", under_p, under_odds_syn),
        ]:
            implied = odds_to_prob(odds_val)
            # Because odds are synthetic we only show slight value or none
            edge = calculate_edge(model_p, implied)
            # Dampen edge for synthetic markets
            edge = round(edge * 0.4, 4)
            signal = determine_value_signal(edge, ConfidenceLevel.MEDIUM)
            markets.append(MarketOdds(
                market=MarketType.TEAM_TOTAL,
                selection=sel,
                odds=odds_val,
                implied_prob=round(implied, 4),
                model_prob=round(model_p, 4),
                edge=edge,
                value_signal=signal,
                movements=[]
            ))

    return markets


def generate_snapshot(
    match: Dict[str, Any],
    model: Dict[str, Any],
    markets: List[MarketOdds],
    uncertainties: List[UncertaintyNote]
) -> AISnapshot:
    home, away = match["home_team"], match["away_team"]
    high_unc = any(u.impact == "high" for u in uncertainties)

    best = None
    for m in markets:
        if m.value_signal in (ValueSignal.STRONG_VALUE, ValueSignal.VALUE, ValueSignal.SLIGHT_VALUE):
            if best is None or m.edge > best.edge:
                best = m

    if high_unc and (best is None or best.edge < 0.06):
        return AISnapshot(
            summary=f"คู่นี้ยังมีจุดที่ไม่แน่นอนสูง (โดยเฉพาะทีมนิวส์) ทำให้ยังไม่สามารถสรุป value ที่ชัดเจนได้ในขณะนี้",
            main_signal=ValueSignal.NO_CLEAR_EDGE,
            confidence=ConfidenceLevel.LOW,
            key_insight="รอทีมนิวส์ที่ชัดเจนก่อนตัดสินใจ",
            recommended_action="ยังไม่มีโอกาสที่ชัดเจน — แนะนำรอดูข้อมูลเพิ่ม"
        )

    if best and best.value_signal in (ValueSignal.STRONG_VALUE, ValueSignal.VALUE):
        return AISnapshot(
            summary=(
                f"โมเดลประเมินว่าตลาดอาจให้ราคาที่คุ้มค่าที่ «{best.selection}» "
                f"(edge {best.edge*100:.1f}%). ความน่าจะเป็นของโมเดล {best.model_prob*100:.1f}% "
                f"เทียบกับ implied ของตลาด {best.implied_prob*100:.1f}%"
            ),
            main_signal=best.value_signal,
            confidence=ConfidenceLevel.HIGH if best.value_signal == ValueSignal.STRONG_VALUE else ConfidenceLevel.MEDIUM,
            key_insight=f"จุดที่น่าสนใจที่สุดคือ {best.selection} ที่ราคา {best.odds}",
            recommended_action=f"พิจารณา {best.selection} หากรับความเสี่ยงในระดับนี้ได้"
        )

    if best and best.value_signal == ValueSignal.SLIGHT_VALUE:
        return AISnapshot(
            summary=(
                f"พบ slight edge ที่ «{best.selection}» (edge {best.edge*100:.1f}%) "
                f"แต่ยังไม่ถึงระดับที่แนะนำให้ลงน้ำหนักมาก"
            ),
            main_signal=ValueSignal.SLIGHT_VALUE,
            confidence=ConfidenceLevel.MEDIUM,
            key_insight=f"มี edge เล็กน้อยที่ {best.selection}",
            recommended_action="สามารถติดตามได้ แต่ยังไม่ใช่ value ที่แข็งแรง"
        )

    # No clear value
    return AISnapshot(
        summary=(
            f"หลังจากวิเคราะห์ข้อมูลทั้งหมด ยังไม่พบจุดที่ตลาดผิดพลาดอย่างมีนัยสำคัญ "
            f"ในคู่นี้ ({home} vs {away}). ราคาปัจจุบันสะท้อนคุณภาพของทั้งสองทีมได้ค่อนข้างดี"
        ),
        main_signal=ValueSignal.NO_CLEAR_EDGE,
        confidence=ConfidenceLevel.MEDIUM,
        key_insight="ตลาดมีประสิทธิภาพดีในคู่นี้",
        recommended_action="ยังไม่มีโอกาสที่ชัดเจน — ไม่แนะนำให้เข้าตลาดในตอนนี้"
    )


# ====================== Main Entry ======================

def get_top_scorelines(score_matrix: dict, top_n: int = 8):
    """ดึงสกอร์ที่โมเดลให้ความน่าจะเป็นสูงสุด"""
    from app.models.schemas import Scoreline
    items = sorted(score_matrix.items(), key=lambda x: x[1], reverse=True)
    return [
        Scoreline(score=f"{h}-{a}", probability=round(p, 4))
        for (h, a), p in items[:top_n]
    ]


def analyze_match(match_id: str) -> MatchAnalysis:
    match = get_match(match_id)
    if not match:
        raise ValueError(f"Match {match_id} not found")

    model = compute_model_probabilities(match)
    facts = build_facts(match)
    analysis_points = build_analysis_points(match, model)
    uncertainties = build_uncertainties(match, model)
    markets = build_markets(match, model)
    snapshot = generate_snapshot(match, model, markets, uncertainties)
    top_scores = get_top_scorelines(model.get("score_matrix", {}))

    return MatchAnalysis(
        match_id=match["match_id"],
        home_team=match["home_team"],
        away_team=match["away_team"],
        competition=match["competition"],
        kickoff=match["kickoff"],
        status=match["status"],
        venue=match.get("venue"),
        facts=facts,
        analysis_points=analysis_points,
        uncertainties=uncertainties,
        snapshot=snapshot,
        model_probabilities={
            "home": round(model["home"], 4),
            "draw": round(model["draw"], 4),
            "away": round(model["away"], 4)
        },
        expected_goals={
            "home": model["home_exp"],
            "away": model["away_exp"],
            "total": round(model["home_exp"] + model["away_exp"], 2)
        },
        top_scorelines=top_scores,
        markets=markets,
        home_form=TeamForm(**match["home_form"]),
        away_form=TeamForm(**match["away_form"]),
        key_players={
            "home": [PlayerStatus(**p) for p in match["key_players"]["home"]],
            "away": [PlayerStatus(**p) for p in match["key_players"]["away"]]
        },
        h2h_summary=f"5 นัดล่าสุด: เจ้าบ้านชนะ {match['h2h']['home_wins']} | เสมอ {match['h2h']['draws']} | ทีมเยือนชนะ {match['h2h']['away_wins']}",
        situational_factors=match["situational"],
        generated_at=datetime.utcnow().isoformat() + "Z"
    )
