"""
Data Service — จุดเดียวที่ระบบดึงข้อมูลคู่แข่งขัน
สลับ sample ↔ real API ได้โดยไม่ต้องแก้ analysis engine
"""

from typing import List, Dict, Any, Optional
from app.providers.factory import get_provider


_provider = None


def _p():
    global _provider
    if _provider is None:
        _provider = get_provider()
    return _provider


def list_matches(competitions: Optional[List[str]] = None) -> List[Dict[str, Any]]:
    return _p().get_upcoming_matches(competitions)


def get_match_data(match_id: str) -> Optional[Dict[str, Any]]:
    return _p().get_match(match_id)


def provider_name() -> str:
    return _p().name


def reset_provider():
    global _provider
    _provider = None
