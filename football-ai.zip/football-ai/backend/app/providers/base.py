"""
Data Provider Interface

ออกแบบให้สลับระหว่าง Sample Data ↔ Real APIs ได้โดยไม่ต้องแก้ analysis engine
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional


class DataProvider(ABC):
    """Interface หลักสำหรับแหล่งข้อมูลฟุตบอล + ตลาด"""

    @abstractmethod
    def get_upcoming_matches(self, competitions: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """ดึงรายการคู่ที่จะแข่ง (โครงสร้างเดียวกับ sample_matches)"""
        pass

    @abstractmethod
    def get_match(self, match_id: str) -> Optional[Dict[str, Any]]:
        """ดึงข้อมูลคู่เดียวแบบละเอียด"""
        pass

    @abstractmethod
    def get_odds(self, match_id: str) -> Optional[Dict[str, Any]]:
        """ดึงราคาตลาดล่าสุดของคู่"""
        pass

    @abstractmethod
    def get_team_news(self, team_name: str) -> List[Dict[str, Any]]:
        """ดึงทีมนิวส์ / injury (optional)"""
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        pass
