"""
Real API Provider (Stub + Integration Ready)

รองรับการเชื่อม:
1. API-Football (api-sports.io) — สถิติ, ฟิกซ์เจอร์, ทีมนิวส์
2. The Odds API (the-odds-api.com) — ราคาและ movement

วิธีใช้:
1. ใส่ API key ใน config หรือ environment variable
2. เปลี่ยน DATA_PROVIDER=api ใน config
3. ระบบจะใช้ข้อมูลจริงแทน sample

หมายเหตุ: ตอนนี้เป็น skeleton ที่พร้อมเติม logic จริง
"""

from typing import List, Dict, Any, Optional
import os
import httpx
from app.providers.base import DataProvider


class APIFootballProvider(DataProvider):
    """
    Provider สำหรับ API-Football + The Odds API

    Environment variables ที่ต้องตั้ง:
    - API_FOOTBALL_KEY
    - ODDS_API_KEY
    """

    BASE_FOOTBALL = "https://v3.football.api-sports.io"
    BASE_ODDS = "https://api.the-odds-api.com/v4"

    def __init__(self):
        self.football_key = os.getenv("API_FOOTBALL_KEY", "")
        self.odds_key = os.getenv("ODDS_API_KEY", "")
        self._client = httpx.Client(timeout=15.0)

    @property
    def name(self) -> str:
        return "api"

    def _football_headers(self) -> Dict[str, str]:
        return {
            "x-apisports-key": self.football_key,
            "Accept": "application/json"
        }

    def get_upcoming_matches(self, competitions: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """
        ดึงฟิกซ์เจอร์จาก API-Football แล้วแปลงเป็นโครงสร้างภายใน

        ตัวอย่าง league ids:
        - Premier League = 39
        - La Liga = 140
        - Serie A = 135
        - Bundesliga = 78
        """
        if not self.football_key:
            raise RuntimeError("API_FOOTBALL_KEY ยังไม่ได้ตั้งค่า")

        league_map = {
            "premier league": 39,
            "la liga": 140,
            "serie a": 135,
            "bundesliga": 78,
        }

        results = []
        leagues_to_fetch = []

        if competitions:
            for c in competitions:
                lid = league_map.get(c.lower())
                if lid:
                    leagues_to_fetch.append(lid)
        else:
            leagues_to_fetch = list(league_map.values())

        for league_id in leagues_to_fetch:
            try:
                resp = self._client.get(
                    f"{self.BASE_FOOTBALL}/fixtures",
                    headers=self._football_headers(),
                    params={"league": league_id, "next": 10, "season": 2025}
                )
                resp.raise_for_status()
                data = resp.json()
                for item in data.get("response", []):
                    results.append(self._normalize_fixture(item))
            except Exception as e:
                # ใน production ควร log
                print(f"[API] fixtures error league={league_id}: {e}")

        return results

    def get_match(self, match_id: str) -> Optional[Dict[str, Any]]:
        """
        ดึงรายละเอียดคู่ + สถิติ + ทีมนิวส์ แล้วรวมเป็นโครงสร้างเดียวกับ sample
        """
        if not self.football_key:
            raise RuntimeError("API_FOOTBALL_KEY ยังไม่ได้ตั้งค่า")

        try:
            # match_id ในระบบจริงควรเป็น fixture id จาก API
            resp = self._client.get(
                f"{self.BASE_FOOTBALL}/fixtures",
                headers=self._football_headers(),
                params={"id": match_id}
            )
            resp.raise_for_status()
            items = resp.json().get("response", [])
            if not items:
                return None
            fixture = self._normalize_fixture(items[0])

            # เติมสถิติ / ฟอร์ม / injury (เรียก endpoint เพิ่มได้)
            # ตัวอย่าง: /fixtures/statistics, /injuries, /fixtures/headtohead
            fixture["odds"] = self.get_odds(match_id) or fixture.get("odds", {})
            return fixture
        except Exception as e:
            print(f"[API] get_match error: {e}")
            return None

    def get_odds(self, match_id: str) -> Optional[Dict[str, Any]]:
        """
        ดึงราคาจาก The Odds API
        ต้อง map sport key และ event ให้ถูกต้อง
        """
        if not self.odds_key:
            return None

        try:
            # ตัวอย่าง: soccer_epl, soccer_spain_la_liga ฯลฯ
            # ใน production ควรเก็บ mapping ของ event id
            resp = self._client.get(
                f"{self.BASE_ODDS}/sports/soccer_epl/odds",
                params={
                    "apiKey": self.odds_key,
                    "regions": "uk,eu",
                    "markets": "h2h,spreads,totals",
                    "oddsFormat": "decimal"
                }
            )
            resp.raise_for_status()
            # แปลง response ให้เข้าโครงสร้าง odds ของเรา
            return self._normalize_odds(resp.json())
        except Exception as e:
            print(f"[API] odds error: {e}")
            return None

    def get_team_news(self, team_name: str) -> List[Dict[str, Any]]:
        if not self.football_key:
            return []
        # ใช้ /injuries endpoint ของ API-Football
        return []

    # ---------- Normalizers ----------

    def _normalize_fixture(self, item: Dict) -> Dict[str, Any]:
        """แปลง response ของ API-Football → โครงสร้างภายใน"""
        fixt = item.get("fixture", {})
        teams = item.get("teams", {})
        league = item.get("league", {})

        return {
            "match_id": str(fixt.get("id", "")),
            "home_team": teams.get("home", {}).get("name", "Home"),
            "away_team": teams.get("away", {}).get("name", "Away"),
            "competition": league.get("name", ""),
            "kickoff": fixt.get("date", ""),
            "status": fixt.get("status", {}).get("short", "NS"),
            "venue": (fixt.get("venue") or {}).get("name", ""),
            # ฟิลด์ด้านล่างต้องเติมจาก endpoint อื่นใน production
            "home_form": {"last_5": [], "goals_scored": 0, "goals_conceded": 0, "xg_for": 1.5, "xg_against": 1.2, "points": 0},
            "away_form": {"last_5": [], "goals_scored": 0, "goals_conceded": 0, "xg_for": 1.4, "xg_against": 1.3, "points": 0},
            "key_players": {"home": [], "away": []},
            "h2h": {"last_5": [], "home_wins": 0, "draws": 0, "away_wins": 0},
            "situational": [],
            "raw_stats": {
                "home_avg_xg": 1.5, "away_avg_xg": 1.4,
                "home_avg_xga": 1.2, "away_avg_xga": 1.3,
                "home_possession": 50, "away_possession": 50,
                "home_ppda": 12, "away_ppda": 12
            },
            "odds": {
                "1X2": {
                    "home": {"opening": 2.0, "current": 2.0},
                    "draw": {"opening": 3.2, "current": 3.2},
                    "away": {"opening": 3.5, "current": 3.5}
                },
                "OU_25": {
                    "over": {"opening": 1.85, "current": 1.85},
                    "under": {"opening": 1.95, "current": 1.95}
                },
                "BTTS": {
                    "yes": {"opening": 1.80, "current": 1.80},
                    "no": {"opening": 2.00, "current": 2.00}
                },
                "AH": {}
            }
        }

    def _normalize_odds(self, data: Any) -> Dict[str, Any]:
        """แปลง The Odds API → โครงสร้าง odds ภายใน (placeholder)"""
        return {
            "1X2": {
                "home": {"opening": 2.0, "current": 2.0},
                "draw": {"opening": 3.2, "current": 3.2},
                "away": {"opening": 3.5, "current": 3.5}
            },
            "OU_25": {
                "over": {"opening": 1.85, "current": 1.85},
                "under": {"opening": 1.95, "current": 1.95}
            },
            "BTTS": {
                "yes": {"opening": 1.80, "current": 1.80},
                "no": {"opening": 2.00, "current": 2.00}
            },
            "AH": {}
        }
