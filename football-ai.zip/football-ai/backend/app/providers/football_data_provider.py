"""
Football-Data.org Provider (FREE forever)

สมัครฟรีที่: https://www.football-data.org/client/register
ได้ token แล้วตั้ง:
  export DATA_PROVIDER=football-data
  export FOOTBALL_DATA_API_TOKEN=your_token_here

Free tier: 10 requests/minute, ลีกใหญ่ครบ (PL, La Liga, Serie A, Bundesliga, Ligue 1, UCL)
Odds ยังใช้ sample / synthetic เพราะไม่มี odds ฟรีคุณภาพสูง
"""

from typing import List, Dict, Any, Optional
import os
from datetime import datetime, timedelta
import httpx

from app.providers.base import DataProvider


# Competition codes ที่ football-data.org ใช้
COMP_MAP = {
    "premier league": "PL",
    "la liga": "PD",
    "serie a": "SA",
    "bundesliga": "BL1",
    "ligue 1": "FL1",
    "champions league": "CL",
}

COMP_NAME = {
    "PL": "Premier League",
    "PD": "La Liga",
    "SA": "Serie A",
    "BL1": "Bundesliga",
    "FL1": "Ligue 1",
    "CL": "Champions League",
}


class FootballDataOrgProvider(DataProvider):
    BASE = "https://api.football-data.org/v4"

    def __init__(self):
        self.token = os.getenv("FOOTBALL_DATA_API_TOKEN", "").strip()
        self._client = httpx.Client(timeout=20.0)
        self._cache: Dict[str, Any] = {}

    @property
    def name(self) -> str:
        return "football-data"

    def _headers(self) -> Dict[str, str]:
        return {
            "X-Auth-Token": self.token,
            "Accept": "application/json",
        }

    def _get(self, path: str, params: Optional[dict] = None) -> Optional[dict]:
        if not self.token:
            return None
        try:
            r = self._client.get(
                f"{self.BASE}{path}",
                headers=self._headers(),
                params=params or {},
            )
            if r.status_code == 200:
                return r.json()
            print(f"[football-data] {path} → {r.status_code}")
            return None
        except Exception as e:
            print(f"[football-data] error: {e}")
            return None

    def get_upcoming_matches(self, competitions: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        codes = []
        if competitions:
            for c in competitions:
                code = COMP_MAP.get(c.lower())
                if code:
                    codes.append(code)
        if not codes:
            codes = ["PL", "PD", "SA", "BL1"]

        results = []
        today = datetime.utcnow().date()
        date_to = (today + timedelta(days=14)).isoformat()
        date_from = today.isoformat()

        for code in codes:
            data = self._get(
                f"/competitions/{code}/matches",
                params={"status": "SCHEDULED", "dateFrom": date_from, "dateTo": date_to},
            )
            if not data:
                continue
            for m in data.get("matches", []):
                normalized = self._normalize_match(m, code)
                if normalized:
                    results.append(normalized)

        # ถ้าไม่มีข้อมูลเลย (ไม่มี token / error) → fallback sample
        if not results:
            from app.data.sample_matches import get_all_matches
            return get_all_matches()

        return results

    def get_match(self, match_id: str) -> Optional[Dict[str, Any]]:
        # ลองดึงจาก API ก่อน
        if match_id.isdigit() or match_id.startswith("fd_"):
            fid = match_id.replace("fd_", "")
            data = self._get(f"/matches/{fid}")
            if data:
                # response อาจเป็น {match: {...}} หรือตัว match โดยตรง
                m = data.get("match") or data
                code = (m.get("competition") or {}).get("code", "PL")
                return self._normalize_match(m, code)

        # fallback sample
        from app.data.sample_matches import get_match
        return get_match(match_id)

    def get_odds(self, match_id: str) -> Optional[Dict[str, Any]]:
        # football-data.org ไม่มี odds ฟรี → ใช้ synthetic จาก sample structure
        m = self.get_match(match_id)
        return m.get("odds") if m else None

    def get_team_news(self, team_name: str) -> List[Dict[str, Any]]:
        return []

    def _normalize_match(self, m: dict, comp_code: str) -> Optional[Dict[str, Any]]:
        try:
            home = m.get("homeTeam") or {}
            away = m.get("awayTeam") or {}
            score = m.get("score") or {}
            full = score.get("fullTime") or {}

            match_id = f"fd_{m.get('id')}"
            status_map = {
                "SCHEDULED": "scheduled",
                "TIMED": "scheduled",
                "IN_PLAY": "live",
                "PAUSED": "live",
                "FINISHED": "finished",
                "POSTPONED": "scheduled",
                "CANCELLED": "scheduled",
            }
            status = status_map.get(m.get("status", ""), "scheduled")

            # สร้าง form / xG แบบประมาณ (เพราะ free tier ไม่มี xG)
            # ใช้ค่ากลาง + variation เล็กน้อยจากชื่อทีม (deterministic)
            h_name = home.get("name") or home.get("shortName") or "Home"
            a_name = away.get("name") or away.get("shortName") or "Away"
            seed_h = sum(ord(c) for c in h_name) % 20
            seed_a = sum(ord(c) for c in a_name) % 20

            home_xg = round(1.2 + (seed_h / 25), 2)
            away_xg = round(1.1 + (seed_a / 28), 2)

            return {
                "match_id": match_id,
                "home_team": h_name,
                "away_team": a_name,
                "competition": COMP_NAME.get(comp_code, comp_code),
                "kickoff": m.get("utcDate", ""),
                "status": status,
                "venue": m.get("venue") or "",
                "home_form": {
                    "last_5": ["W", "D", "W", "L", "W"],
                    "goals_scored": 8 + seed_h // 3,
                    "goals_conceded": 5 + seed_a // 4,
                    "xg_for": home_xg * 5,
                    "xg_against": away_xg * 4.5,
                    "points": 7 + seed_h // 4,
                },
                "away_form": {
                    "last_5": ["D", "W", "L", "W", "D"],
                    "goals_scored": 7 + seed_a // 3,
                    "goals_conceded": 6 + seed_h // 4,
                    "xg_for": away_xg * 5,
                    "xg_against": home_xg * 4.5,
                    "points": 6 + seed_a // 4,
                },
                "key_players": {"home": [], "away": []},
                "h2h": {
                    "last_5": [],
                    "home_wins": 0,
                    "draws": 0,
                    "away_wins": 0,
                },
                "situational": [
                    f"ข้อมูลจาก football-data.org (ฟรี) — {COMP_NAME.get(comp_code, comp_code)}",
                    "xG และฟอร์มเป็นค่าประมาณ เพราะ free tier ไม่มี advanced stats",
                    "Odds เป็น synthetic สำหรับการวิเคราะห์ Value",
                ],
                "raw_stats": {
                    "home_avg_xg": home_xg,
                    "away_avg_xg": away_xg,
                    "home_avg_xga": round(1.0 + seed_a / 30, 2),
                    "away_avg_xga": round(1.1 + seed_h / 30, 2),
                    "home_possession": 50 + seed_h % 10,
                    "away_possession": 50 - seed_h % 10,
                    "home_ppda": 11.0,
                    "away_ppda": 12.0,
                },
                "odds": self._synthetic_odds(home_xg, away_xg),
            }
        except Exception as e:
            print(f"[football-data] normalize error: {e}")
            return None

    def _synthetic_odds(self, home_xg: float, away_xg: float) -> dict:
        """สร้างราคาประมาณจาก xG เพื่อให้ Value Detection ทำงานได้"""
        diff = home_xg - away_xg
        if diff > 0.4:
            h, d, a = 1.75, 3.60, 4.50
        elif diff > 0.15:
            h, d, a = 2.10, 3.40, 3.40
        elif diff > -0.15:
            h, d, a = 2.40, 3.30, 2.90
        elif diff > -0.4:
            h, d, a = 3.20, 3.40, 2.20
        else:
            h, d, a = 4.20, 3.60, 1.80

        total = home_xg + away_xg
        over = 1.70 if total > 2.6 else 2.00
        under = round(1 / (1 - 1 / over * 0.95) * 0.95, 2) if over > 1.01 else 2.10

        return {
            "1X2": {
                "home": {"opening": h + 0.05, "current": h},
                "draw": {"opening": d, "current": d},
                "away": {"opening": a + 0.05, "current": a},
            },
            "OU_25": {
                "over": {"opening": over + 0.03, "current": over},
                "under": {"opening": under, "current": under},
            },
            "BTTS": {
                "yes": {"opening": 1.75, "current": 1.72},
                "no": {"opening": 2.10, "current": 2.15},
            },
            "AH": {
                "home_-0.25": {"opening": 1.95, "current": 1.90},
                "away_+0.25": {"opening": 1.95, "current": 2.00},
            },
        }
