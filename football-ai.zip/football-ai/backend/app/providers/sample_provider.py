"""
Sample Data Provider — ใช้ข้อมูลใน sample_matches.py
"""

from typing import List, Dict, Any, Optional
from app.providers.base import DataProvider
from app.data.sample_matches import get_all_matches, get_match, SAMPLE_MATCHES


class SampleDataProvider(DataProvider):
    @property
    def name(self) -> str:
        return "sample"

    def get_upcoming_matches(self, competitions: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        matches = get_all_matches()
        if competitions:
            comps = [c.lower() for c in competitions]
            matches = [m for m in matches if any(c in m["competition"].lower() for c in comps)]
        return matches

    def get_match(self, match_id: str) -> Optional[Dict[str, Any]]:
        return get_match(match_id)

    def get_odds(self, match_id: str) -> Optional[Dict[str, Any]]:
        m = get_match(match_id)
        return m.get("odds") if m else None

    def get_team_news(self, team_name: str) -> List[Dict[str, Any]]:
        # สร้างจาก key_players ใน sample
        news = []
        for m in get_all_matches():
            for side in ("home", "away"):
                if m[f"{side}_team"].lower() == team_name.lower():
                    for p in m["key_players"][side]:
                        if p["status"] != "available":
                            news.append({
                                "player": p["name"],
                                "status": p["status"],
                                "impact": p["impact"],
                                "team": m[f"{side}_team"]
                            })
        return news
