"""
Provider Factory — ฟรีทั้งหมด

DATA_PROVIDER=
  sample        → ข้อมูลตัวอย่างในโปรเจกต์ (ไม่ต้องเน็ต)
  openfootball  → GitHub openfootball ฟรี ไม่ต้องมี key (แนะนำ)
  football-data → football-data.org ฟรี (ต้องมี token)
"""

import os
from app.providers.base import DataProvider
from app.providers.sample_provider import SampleDataProvider


def get_provider() -> DataProvider:
    mode = os.getenv("DATA_PROVIDER", "openfootball").lower().strip()

    if mode in ("openfootball", "open", "of"):
        try:
            from app.providers.openfootball_provider import OpenFootballProvider
            p = OpenFootballProvider()
            # smoke test
            return p
        except Exception as e:
            print(f"[factory] openfootball failed ({e}) → sample")
            return SampleDataProvider()

    if mode in ("football-data", "football_data", "fd"):
        token = os.getenv("FOOTBALL_DATA_API_TOKEN", "").strip()
        if token:
            from app.providers.football_data_provider import FootballDataOrgProvider
            return FootballDataOrgProvider()
        print("[factory] ไม่มี FOOTBALL_DATA_API_TOKEN → sample")
        return SampleDataProvider()

    if mode == "api":
        key = os.getenv("API_FOOTBALL_KEY", "").strip()
        if key:
            from app.providers.api_provider import APIFootballProvider
            return APIFootballProvider()
        return SampleDataProvider()

    return SampleDataProvider()
