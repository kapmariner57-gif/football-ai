from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from enum import Enum
from datetime import datetime


class ConfidenceLevel(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INSUFFICIENT = "insufficient"


class ValueSignal(str, Enum):
    STRONG_VALUE = "strong_value"
    VALUE = "value"
    SLIGHT_VALUE = "slight_value"
    NO_CLEAR_EDGE = "no_clear_edge"
    AVOID = "avoid"


class MarketType(str, Enum):
    MATCH_RESULT = "1X2"
    ASIAN_HANDICAP = "AH"
    OVER_UNDER = "OU"
    BTTS = "BTTS"
    TEAM_TOTAL = "TT"


class TeamForm(BaseModel):
    last_5: List[str]  # W, D, L
    goals_scored: int
    goals_conceded: int
    xg_for: float
    xg_against: float
    points: int


class PlayerStatus(BaseModel):
    name: str
    position: str
    status: str  # available, injured, suspended, doubtful
    impact: str  # high, medium, low


class OddsMovement(BaseModel):
    bookmaker: str
    opening: float
    current: float
    movement: float  # percentage change
    direction: str  # shortening, drifting


class MarketOdds(BaseModel):
    market: MarketType
    selection: str
    odds: float
    implied_prob: float
    model_prob: float
    edge: float  # model_prob - implied_prob
    value_signal: ValueSignal
    movements: List[OddsMovement] = []


class FactItem(BaseModel):
    category: str
    text: str
    source: str = "official"
    confidence: ConfidenceLevel = ConfidenceLevel.HIGH


class AnalysisPoint(BaseModel):
    title: str
    content: str
    supporting_facts: List[str] = []
    confidence: ConfidenceLevel


class UncertaintyNote(BaseModel):
    area: str
    description: str
    impact: str  # high, medium, low


class AISnapshot(BaseModel):
    summary: str
    main_signal: ValueSignal
    confidence: ConfidenceLevel
    key_insight: str
    recommended_action: str


class Scoreline(BaseModel):
    score: str          # e.g. "2-1"
    probability: float


class MatchAnalysis(BaseModel):
    match_id: str
    home_team: str
    away_team: str
    competition: str
    kickoff: str
    status: str  # scheduled, live, finished
    venue: Optional[str] = None

    # Layers
    facts: List[FactItem]
    analysis_points: List[AnalysisPoint]
    uncertainties: List[UncertaintyNote]

    # AI Core
    snapshot: AISnapshot
    model_probabilities: Dict[str, float]  # home, draw, away
    expected_goals: Dict[str, float]       # home, away, total
    top_scorelines: List[Scoreline] = []
    markets: List[MarketOdds]

    # Context
    home_form: TeamForm
    away_form: TeamForm
    key_players: Dict[str, List[PlayerStatus]]
    h2h_summary: str
    situational_factors: List[str]

    generated_at: str


class MatchSummary(BaseModel):
    match_id: str
    home_team: str
    away_team: str
    competition: str
    kickoff: str
    status: str
    main_signal: ValueSignal
    confidence: ConfidenceLevel
    short_summary: str
    model_home_win: float
    model_draw: float
    model_away_win: float
