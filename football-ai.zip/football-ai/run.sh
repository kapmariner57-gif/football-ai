#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/backend"

echo "=========================================="
echo "  Football AI Intelligence Platform"
echo "=========================================="

# ติดตั้ง dependencies ถ้ายังไม่มี
python -c "import fastapi, uvicorn" 2>/dev/null || {
  echo ">> กำลังติดตั้ง dependencies..."
  pip install -r requirements.txt --break-system-packages -q 2>/dev/null || \
  pip install -r requirements.txt -q
}

export DATA_PROVIDER="${DATA_PROVIDER:-openfootball}"

echo ">> Data Provider: $DATA_PROVIDER"
echo ">> Starting server at http://0.0.0.0:8000"
echo ">> เปิดเบราว์เซอร์ไปที่ http://localhost:8000"
echo ">> API Docs: http://localhost:8000/docs"
echo "=========================================="

exec python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
