# Football AI Intelligence Platform

แพลตฟอร์มวิเคราะห์และค้นหาความคุ้มค่าฟุตบอลที่ **AI เป็นหัวใจ**

ระบบนี้ไม่ได้ทายผลแบบมั่ว ๆ แต่:
- รวบรวมข้อมูล → วิเคราะห์ด้วย Poisson model
- เปรียบเทียบกับราคาตลาด (ถอด vig)
- ค้นหาจุดที่มี Value จริง
- **แยก Fact / Analysis / Uncertainty ชัดเจน**
- **กล้าบอกว่า “ยังไม่มีโอกาสที่ชัดเจน”** เมื่อข้อมูลไม่พอ

---

## วิธีรัน (พร้อมใช้ทันที)

```bash
cd football-ai
./run.sh
```

จากนั้นเปิดเบราว์เซอร์ไปที่:

**http://localhost:8000**

| หน้า | URL |
|------|-----|
| เว็บหลัก | http://localhost:8000 |
| API Docs | http://localhost:8000/docs |
| Health | http://localhost:8000/api/health |
| Value Board | http://localhost:8000/api/matches/value-board |

---

## สิ่งที่ระบบทำได้

### หน้าเว็บ
- **Value Board** — รวมทุกตลาดจากทุกคู่ที่มี edge
- รายการคู่ + Filter ตาม Signal / ลีก
- หน้า Match Detail ครบ:
  - AI Snapshot (สรุป + recommended action)
  - Model Probabilities (1X2)
  - Expected Goals
  - Correct Score ที่โมเดลให้โอกาสสูงสุด
  - ตาราง Market Comparison & Value
  - Fact Layer / Analysis Layer / Uncertainty Layer
  - ฟอร์ม + ผู้เล่นสำคัญ + Situational Factors

### ตลาดที่วิเคราะห์
- 1X2
- Over/Under 2.5
- BTTS
- Asian Handicap (คำนวณจาก score matrix)
- Team Total (Home/Away Over-Under 1.5)

### หลักการ Value Detection (Conservative)
| Signal | เงื่อนไข |
|--------|----------|
| Strong Value | edge ≥ 8% + confidence สูง |
| Value | edge ≥ 5% |
| Slight Value | edge ≥ 3% |
| No Clear Edge | นอกนั้น (ระบบจะบอกตรง ๆ) |
| Avoid | edge ≤ -7% |

---

## โครงสร้างโปรเจกต์

```
football-ai/
├── run.sh                          ← รันด้วยคำสั่งนี้
├── .env.example
├── README.md
├── backend/
│   ├── requirements.txt
│   └── app/
│       ├── main.py                 ← FastAPI entry
│       ├── config.py
│       ├── models/schemas.py
│       ├── routers/matches.py      ← API endpoints
│       ├── services/
│       │   ├── analysis_engine.py  ← หัวใจ (Poisson + Value)
│       │   └── data_service.py
│       ├── providers/              ← สลับ sample ↔ real API
│       │   ├── base.py
│       │   ├── sample_provider.py
│       │   ├── api_provider.py
│       │   └── factory.py
│       └── data/sample_matches.py  ← 9 คู่ · 4 ลีก
└── frontend/public/index.html      ← UI สมบูรณ์
```

---

## ข้อมูลตัวอย่างที่มี

| ลีก | คู่ |
|-----|-----|
| Premier League | Arsenal–Man City, Liverpool–Chelsea, Spurs–Villa, Man Utd–Newcastle, Brighton–West Ham |
| La Liga | Real Madrid–Barcelona, Atlético–Sevilla |
| Serie A | Inter–Juventus |
| Bundesliga | Bayern–Dortmund |

---

## เปลี่ยนเป็นข้อมูลจริง

```bash
export DATA_PROVIDER=api
export API_FOOTBALL_KEY=your_key
export ODDS_API_KEY=your_odds_key
./run.sh
```

ดูรายละเอียดใน `backend/app/providers/api_provider.py`

API ที่แนะนำ:
- **API-Football** (api-sports.io) → ฟิกซ์เจอร์, สถิติ, injury
- **The Odds API** → ราคาและ movement

---

## API หลัก

| Method | Endpoint | คำอธิบาย |
|--------|----------|----------|
| GET | `/api/health` | สถานะระบบ + provider |
| GET | `/api/matches/` | รายการคู่ + filter (`?signal=value&competition=Premier%20League`) |
| GET | `/api/matches/value-board` | รวมจุดที่มี edge (`?min_edge=0.03`) |
| GET | `/api/matches/{id}` | วิเคราะห์ละเอียดครบทุกชั้น |

---

## หลักการออกแบบ

1. **Truth over prediction** — บอกเมื่อไม่รู้ ดีกว่าทายแรง
2. **แยก 3 ชั้น** — Fact ≠ Analysis ≠ Uncertainty
3. **Market เป็น benchmark** — หาจุดที่โมเดลต่างจากตลาดอย่างมีเหตุผล
4. **Conservative value** — แสดงน้อยแต่คุณภาพสูง
5. **Explainable** — ผู้ใช้ต้องเข้าใจว่าทำไม AI ถึงคิดอย่างนั้น

---

สร้างตามเป้าหมาย:  
**ข้อมูลจำนวนมาก → AI วิเคราะห์ → เข้าใจสถานการณ์ → ประเมินความเป็นไปได้ → เปรียบเทียบตลาด → ค้นหาความคุ้มค่า → สรุปให้ง่าย และกล้าบอกเมื่อไม่ชัดเจน**

---

## ใช้ข้อมูลจริงแบบฟรี (football-data.org)

1. สมัครฟรีที่ https://www.football-data.org/client/register
2. คัดลอก API Token
3. รัน:

```bash
export DATA_PROVIDER=football-data
export FOOTBALL_DATA_API_TOKEN=ใส่_token_ของคุณ
./run.sh
```

Free tier: 10 requests/นาที · ลีกใหญ่ครบ (PL, La Liga, Serie A, Bundesliga, Ligue 1, UCL)  
Odds ยังเป็น synthetic เพราะไม่มีแหล่ง odds ฟรีคุณภาพสูง
